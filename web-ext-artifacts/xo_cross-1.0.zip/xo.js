const el = document.getElementsByTagName("header")[0];
el.remove();

